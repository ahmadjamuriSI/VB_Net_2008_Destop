﻿Public Class FormLaporanSupplier

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnTampilkan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTampilkan.Click
        CrystalReportViewer1.SelectionFormula = "{tbsupplier.kodesupplier}='" & tbCariSupplier.Text & "'"
        CrystalReportViewer1.ReportSource = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 adm\DataBase-VB-main\DBPembelian.mdb"
    End Sub

    Private Sub btnTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTutup.Click
        Menu_Utama.Show()
        Me.Hide()
    End Sub
End Class
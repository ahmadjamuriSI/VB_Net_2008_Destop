﻿Imports System.IO
Public Class menulisfile

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim fileWriter As StreamWriter
        Try
            fileWriter = New StreamWriter("C:\Users\User\Desktop\latihan pemrograman.vb\menulisfilepadanotepad\biodata.txt")
            fileWriter.Write(TextBox1.Text)
            fileWriter.Write(TextBox2.Text)
            fileWriter.Close()
            MessageBox.Show("data sudah di simpan")
            TextBox1.Text = ""
            TextBox2.Text = ""
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class

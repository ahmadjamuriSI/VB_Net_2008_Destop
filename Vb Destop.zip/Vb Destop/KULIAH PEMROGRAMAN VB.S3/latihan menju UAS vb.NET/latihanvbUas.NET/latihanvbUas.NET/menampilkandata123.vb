﻿Public Class menampilkandata123

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
       
    End Sub

    Private Sub CheckBoxKuning_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxKuning.CheckedChanged

    End Sub

    Private Sub CheckBoxHijau_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxHijau.CheckedChanged

    End Sub

    Private Sub CheckBoxBiru_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxBiru.CheckedChanged

    End Sub
End Class
﻿Public Class Menampilkandata

    Private Sub txtNama_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPanggilan.TextChanged

    End Sub

    Private Sub bProses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bProses.Click
        Dim Arr(2) As String
        Arr(0) = txtNama.Text
        Arr(1) = txtPanggilan.Text


        Dim listitem As ListViewItem
        listitem = New ListViewItem
        listitem = ListView1.Items.Add(Arr(0))
        listitem.SubItems.Add(Arr(1))
        listitem.SubItems.Add(Arr(2))
        txtNama.Text = txtNama.Text
        txtPanggilan.Text = ""
        txtPanggilan.Focus()
    End Sub

    Private Sub Menampilkandata_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListView1.GridLines = True
        ListView1.View = View.Details
        ListView1.Columns.Add("Nama")
        ListView1.Columns.Add("Panggilan", 115)
        txtNama.Text = ""
        txtPanggilan.Focus()
    End Sub
End Class
﻿Public Class fromTampilanvb

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MessageBox.Show(txtNama.Text & vbCrLf & ComboBox1.Text & vbCrLf & ComboBox2.Text, "Hasil Pengisian", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Class
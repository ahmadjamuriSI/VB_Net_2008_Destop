﻿Public Class MenulisfilekeNotepadlatihan2
    Dim fileWriter As IO.StreamWriter
    Dim Npm, Nama, Jurusan, alamat As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            fileWriter = New IO.StreamWriter("C:\Users\User\Desktop\latihan menju UAS vb.NET\latihanvbUas.NET\Biodata.txt")
            fileWriter.Write(Npm)
            fileWriter.Write(Nama)
            fileWriter.Write(Jurusan)
            fileWriter.Write(alamat)

            fileWriter.Close()
            MessageBox.Show("")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
        Npm = TextBox3.Text
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Nama = TextBox1.Text
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        Jurusan = TextBox4.Text
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        alamat = TextBox2.Text
    End Sub

End Class
﻿Public Class Menghitungjaraklatihan1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim kecepatan As Double
        Dim waktutempuh As Double
        Dim jarak As Double

        jarak = TextBox1.Text
        kecepatan = TextBox2.Text
        waktutempuh = jarak / kecepatan
        TextBox3.Text = waktutempuh

        ListBox1.Items.Add(waktutempuh)
    End Sub
End Class
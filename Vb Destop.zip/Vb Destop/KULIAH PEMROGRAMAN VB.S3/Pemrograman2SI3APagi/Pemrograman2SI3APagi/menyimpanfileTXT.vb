﻿Imports System.IO
Public Class menyimpanfileTXT
    Dim fileWriter As StreamWriter
    Dim nama, alamat As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Try
            fileWriter = New StreamWriter("C:\Users\User\Desktop\vb\Pemrograman2SI3APagi\Biodata.txt")
            fileWriter.Write(nama)
            fileWriter.Write(alamat)

            fileWriter.Close()
            MessageBox.Show("AHMAD JAMURI")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        nama = TextBox1.Text
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        alamat = TextBox2.Text
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class
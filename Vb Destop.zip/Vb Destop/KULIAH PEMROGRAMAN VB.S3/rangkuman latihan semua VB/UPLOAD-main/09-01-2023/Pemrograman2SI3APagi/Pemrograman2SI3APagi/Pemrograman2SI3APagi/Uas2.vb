﻿Public Class Uas2
    Dim kuning, hijau, biru As String
    Private Sub btnTampilkan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTampilkan.Click
        lblNim.Text = txtNim.Text
        lblNama.Text = txtNama.Text
        lblWarna.Text = "1. " & kuning & vbCrLf & "2. " & hijau & vbCrLf & "3. " & biru & vbCrLf
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Close()
    End Sub

    Private Sub rbKuning_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbKuning.CheckedChanged
        kuning = rbKuning.Text
    End Sub

    Private Sub rbHijau_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbHijau.CheckedChanged
        hijau = rbHijau.Text
    End Sub

    Private Sub rbBiru_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbBiru.CheckedChanged
        biru = rbBiru.Text
    End Sub
End Class
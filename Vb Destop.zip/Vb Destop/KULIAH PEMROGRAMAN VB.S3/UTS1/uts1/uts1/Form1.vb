﻿Public Class UTS1

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        txtNama.Text = ""
        txtHargaSandal.Text = ""
        txtJumlahSand.Text = ""
        txtTotalBayar.Text = ""
        txtDiskon.Text = ""
        txtTotalHarg.Text = ""
        txtBonus.Text = ""
        txtKupon.Text = ""
        txtNama.Focus()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim harga, jumlah As Integer
        Dim total, diskon, bayar As Double
        Dim bonus, kupon As String
        'Deklarasi Input Harga dan Jumlah

        harga = txtHargaSandal.Text
        jumlah = txtJumlahSand.Text
        'Perhitungan Total Harga
        total = harga * jumlah
        'Penentuan Discon dan Bonus
        If total >= 700000 Then
            diskon = 0.3 * total
            bonus = "Baju Tidur"
            kupon = "22"
        ElseIf total >= 300000 Then
            diskon = 0.2 * total
            bonus = "Topi Anak"
            kupon = "19"
        ElseIf total >= 200000 Then
            diskon = 0.15 * total
            bonus = "Kaos Anak"
            kupon = "15"
        ElseIf total >= 10000 Then
            diskon = 0.1 * total
            bonus = "Sapu Tangan"
            kupon = "5"
        Else
            diskon = 0
            bonus = "Tidak Ada"
            kupon = 0
        End If
19:
        'Perhitungan total Bayar
        bayar = total - diskon

        'Deklarasi keluaran total Harga, diskon,total bayar, bonus,diskon
        txtTotalHarg.Text = total
        txtDiskon.Text = diskon
        txtTotalBayar.Text = bayar
        txtBonus.Text = bonus
        txtKupon.Text = kupon
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
End Class

﻿Imports System.Data.OleDb

Public Class iniputdatamobil
    Dim conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim rd As OleDbDataReader
    Dim str As String
    Sub koneksi()
        str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PROGRAMAN VB.S4\Ahmad Jamuri\Latihan1\DBLatihan.mdb"
        conn = New OleDbConnection(str)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub
    Sub Tampilgrid()
        Da = New OleDbDataAdapter("select * from tbmobil", conn)
        ds = New DataSet
        Da.Fill(ds, "tbmobil")
        DataGridView1.DataSource = ds.Tables("tbmobil")
    End Sub
    Sub Tampilan()
        TextBox2.Text = rd.Item(1)
        ComboBox1.Text = rd.Item(2)
        ComboBox2.Text = rd.Item(3)
    End Sub
    Sub TextMati()
        Me.TextBox1.Enabled = False
        Me.TextBox2.Enabled = False
        Me.ComboBox1.Enabled = False
        Me.ComboBox2.Enabled = False
    End Sub
    Sub TextHidup()
        Me.TextBox1.Enabled = True
        Me.TextBox2.Enabled = True
        Me.ComboBox1.Enabled = True
        Me.ComboBox2.Enabled = True
    End Sub
    Sub kosong()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox1.Focus()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        Call Tampilgrid()
        Call kosong()
        Call TextMati()
        DataGridView1.ReadOnly = True
        DataGridView1.Enabled = True
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call kosong()
        Call TextHidup()
        Me.btnTambah.Enabled = False
        Me.btnSimpan.Enabled = True
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If TextBox1.Text = "" Or TextBox1.Text = "" Or ComboBox1.Text = "" Then
            MsgBox("Data Belum Lengkap, Pastikan Semua Form Terisi")
            Exit Sub
        Else
            Call koneksi()
            Dim simpan As String = "insert into tbmobil (type_mobil,nama_mobil,harga,warna_mobil)" & _
            "Values ('" & TextBox1.Text & "','" & ComboBox1.Text & "','" & TextBox2.Text & "','" & ComboBox2.Text & "')"
            cmd = New OleDbCommand(simpan, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil di Input", MsgBoxStyle.Information, "Information")
            Me.OleDbConnection1.Close()
            Call Tampilgrid()
            DataGridView1.Refresh()
            Call koneksi()
            Call kosong()
            Call TextMati()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnKeluar.Enabled = True
        End If
    End Sub


    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class

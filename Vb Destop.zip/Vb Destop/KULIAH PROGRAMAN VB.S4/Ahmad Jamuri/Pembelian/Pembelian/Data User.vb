﻿Imports System.Data.OleDb

Public Class Data_User

    Dim conn As OleDbConnection
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim rd As OleDbDataReader
    Dim str As String
    Sub Koneksi()
        str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PROGRAMAN VB.S4\Ahmad Jamuri\Pembelian\Database\DBPembelian.mdb"
        conn = New OleDbConnection(str)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub
    Sub Tampilgrid()
        da = New OleDbDataAdapter("select * from tbuser", conn)
        ds = New DataSet
        da.Fill(ds, "tbuser")
        DataGridView1.DataSource = ds.Tables("tbuser")
    End Sub
    Sub Tampildata()
        tbpassword.Text = rd.Item(1)
        cbbagian.Text = rd.Item(2)
    End Sub
    Sub TextMati()
        Me.tbiduser.Enabled = False
        Me.tbpassword.Enabled = False
        Me.cbbagian.Enabled = False
    End Sub
    Sub TextHidup()
        Me.tbiduser.Enabled = True
        Me.tbpassword.Enabled = True
        Me.cbbagian.Enabled = True
    End Sub
    Sub KOSONGKAN()
        tbiduser.Clear()
        tbpassword.Clear()
    End Sub


    Private Sub Data_User_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MsgBox(Now)
        Call Koneksi()
        Call Tampilgrid()
        Call TextMati()
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnBatal.Enabled = False
        Me.btnHapus.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call KOSONGKAN()
        Call TextHidup()
        Me.tbiduser.Focus()
        Me.btnTambah.Enabled = False
        Me.btnSimpan.Enabled = True

        Me.btnEdit.Enabled = False
        Me.btnBatal.Enabled = False
        Me.btnHapus.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If tbiduser.Text = "" Or tbpassword.Text = "" Or cbbagian.Text = "" Then
            MsgBox("Data belum lengkap, Pastikan Semua form terisi")
            Exit Sub
        Else
            Call Koneksi()
            Dim simpan As String = "insert into tbuser (iduser,passworduser,bagian)" & _
            " values ('" & tbiduser.Text & "','" & tbpassword.Text & "','" & cbbagian.Text & "')"
            cmd = New OleDbCommand(simpan, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data berhasil di Simpan", MsgBoxStyle.Information, "Information")
            Me.OleDbConnection1.Close()
            Call Tampilgrid()
            DataGridView1.Refresh()
            Call Koneksi()
            Call KOSONGKAN()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnEdit.Enabled = False
            Me.btnBatal.Enabled = False
            Me.btnHapus.Enabled = False
            Me.btnKeluar.Enabled = True
        End If
    End Sub

    Private Sub OdbcConnection1_InfoMessage(ByVal sender As System.Object, ByVal e As System.Data.Odbc.OdbcInfoMessageEventArgs)

    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Call TextHidup()
        tbiduser.Enabled = False
        Me.btnTambah.Enabled = False
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnBatal.Enabled = True
        Me.btnHapus.Enabled = True
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Call KOSONGKAN()
        Call TextMati()
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnBatal.Enabled = False
        Me.btnHapus.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        If tbiduser.Text = "" Then
            MsgBox("Kode belum diisi")
            tbiduser.Focus()
            Exit Sub
        Else
If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) =Windows.Forms.DialogResult.Yes Then
                Dim hapus As String = "Delete * from tbuser where username='" & tbiduser.Text & "'"
                cmd = New OleDbCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call Tampilgrid()
                Call KOSONGKAN()
                Me.btnTambah.Enabled = True
                Me.btnSimpan.Enabled = False
                Me.btnEdit.Enabled = False
                Me.btnBatal.Enabled = False
                Me.btnHapus.Enabled = False
                Me.btnKeluar.Enabled = True
            Else
                Call TextMati()
            End If
        End If
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        menuutama.Show()
        Me.Hide()
    End Sub

    Private Sub OleDbConnection1_InfoMessage(ByVal sender As System.Object, ByVal e As System.Data.OleDb.OleDbInfoMessageEventArgs)

    End Sub
End Class
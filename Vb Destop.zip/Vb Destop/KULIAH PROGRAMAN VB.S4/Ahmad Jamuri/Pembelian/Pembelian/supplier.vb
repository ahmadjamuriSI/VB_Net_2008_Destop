﻿Imports System.Data.OleDb
Public Class supplier
    Dim conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim rd As OleDbDataReader
    Dim str As String
    Sub koneksi()
        str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PROGRAMAN VB.S4\Ahmad Jamuri\Pembelian\Database\DBPembelian.mdb"
        conn = New OleDbConnection(str)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub
    Sub Tampilgrid()
        Da = New OleDbDataAdapter("select * from tbsupplier", conn)
        ds = New DataSet
        Da.Fill(ds, "tbsupplier")
        DataSupplier.DataSource = ds.Tables("tbsupplier")
    End Sub
    Sub Tampilan()
        Tbkodesupplier.Text = rd.Item(1)
        Tbnamasupplier.Text = rd.Item(2)
        Tbtelepon.Text = rd.Item(3)
        Tbemail.Text = rd.Item(4)
        Tbalamat.Text = rd.Item(5)
    End Sub
    Sub TextMati()
        Me.Tbkodesupplier.Enabled = False
        Me.Tbnamasupplier.Enabled = False
        Me.Tbtelepon.Enabled = False
        Me.Tbemail.Enabled = False
        Me.Tbemail.Enabled = False
    End Sub
    Sub TextHidup()
        Me.Tbkodesupplier.Enabled = True
        Me.Tbnamasupplier.Enabled = True
        Me.Tbtelepon.Enabled = True
        Me.Tbemail.Enabled = True
        Me.Tbalamat.Enabled = True
    End Sub
    Sub kosong()
        Tbkodesupplier.Clear()
        Tbnamasupplier.Clear()
        Tbtelepon.Clear()
        Tbemail.Clear()
        Tbemail.Focus()
    End Sub

    Private Sub supplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksi()
        Call Tampilgrid()
        Call kosong()
        Call TextMati()
        DataSupplier.ReadOnly = True
        DataSupplier.Enabled = True
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnBatal.Enabled = False
        Me.btnUpdate.Enabled = False
        Me.btnHapus.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call kosong()
        Call TextHidup()
        Me.btnTambah.Enabled = False
        Me.btnSimpan.Enabled = True
        Me.btnEdit.Enabled = True
        Me.btnBatal.Enabled = False
        Me.btnUpdate.Enabled = False
        Me.btnHapus.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        menuutama.Show()
        Me.Hide()
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If Tbkodesupplier.Text = "" Or Tbnamasupplier.Text = "" Or Tbtelepon.Text = "" Or Tbemail.Text = "" Or Tbalamat.Text = "" Then
            MsgBox("Data belum lengkap, pastikan semua form terisi")
            Exit Sub
        Else
            Call koneksi()
            Dim simpan As String = "insert into tbsupplier (kdsupp,nmsupp,telpon,email,alamat)" & _
            "Values ('" & Tbkodesupplier.Text & "','" & Tbnamasupplier.Text & "','" & Tbtelepon.Text & "','" & Tbemail.Text & "','" & Tbalamat.Text & "')"
            cmd = New OleDbCommand(simpan, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil di Input", MsgBoxStyle.Information, "Information")
            Me.OleDbConnection1.Close()
            Call Tampilgrid()
            DataSupplier.Refresh()
            Call koneksi()
            Call kosong()
            Call TextMati()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnEdit.Enabled = False
            Me.btnUpdate.Enabled = False
            Me.btnBatal.Enabled = False
            Me.btnHapus.Enabled = False
            Me.btnKeluar.Enabled = True
        End If
    End Sub

    Private Sub Tbkodesupplier_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Tbkodesupplier.KeyPress
        Tbkodesupplier.MaxLength = 5
        If e.KeyChar = Chr(13) Then Tbnamasupplier.Focus()
    End Sub

    Private Sub Tbkodesupplier_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Tbkodesupplier.LostFocus
        str = "SELECT * FROM tbsupplier Where kdsupp = '" & Tbkodesupplier.Text & "'"
        cmd = New OleDbCommand(str, conn)
        rd = cmd.ExecuteReader
        Try
            While rd.Read
                Tbnamasupplier.Text = rd.GetString(1)
                Tbkodesupplier.Text = rd.GetString(2)
                Tbtelepon.Text = rd.GetValue(3)
                Tbemail.Text = rd.GetValue(4)
                Tbalamat.Text = rd.GetValue(4)
                TextMati()
                Me.btnTambah.Enabled = True
                Me.btnSimpan.Enabled = False
                Me.btnEdit.Enabled = True
                Me.btnUpdate.Enabled = True
                Me.btnBatal.Enabled = True
                Me.btnHapus.Enabled = True
                Me.btnKeluar.Enabled = True
            End While
        Finally
            rd.Close()
        End Try
    End Sub

    Private Sub Tbkodesupplier_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tbkodesupplier.TextChanged

    End Sub

    Private Sub DataSupplier_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataSupplier.CellContentClick

    End Sub
End Class
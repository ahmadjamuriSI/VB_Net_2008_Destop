﻿Public Class laporanbarang


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CrystalReportViewer1.SelectionFormula = "{tbbarang.kdbarang}='" & TextBox1.Text & "'"
        CrystalReportViewer1.ReportSource = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PROGRAMAN VB.S4\Ahmad Jamuri\Pembelian\Database\DBPembelian.mdb"
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        menuutama.Show()
        Me.Hide()
    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class
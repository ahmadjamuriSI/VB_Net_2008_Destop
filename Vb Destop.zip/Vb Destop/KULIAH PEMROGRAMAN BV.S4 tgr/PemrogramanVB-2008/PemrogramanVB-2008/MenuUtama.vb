﻿Public Class MenuUtama
    ' [MENU ITEM]: Link menuju form InputDataBarang.vb.
    Private Sub DataBarangToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataBarangToolStripMenuItem.Click
        InputDataBarang.Show()
        Me.Hide()
    End Sub

    ' [MENU ITEM]: Link untuk keluar dari MenuUtama.vb.
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        FormLogin.Show()
        Me.Hide()
    End Sub

    ' [MENU ITEM]: Link menuju form FormLaporanBarang.vb.
    Private Sub LapDataBarangToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LapDataBarangToolStripMenuItem.Click
        FormLaporanBarang.Show()
        Me.Hide()
    End Sub

    ' [MENU ITEM]: Link menuju form InputDataUser.vb.
    Private Sub TambahUserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TambahUserToolStripMenuItem.Click
        InputDataUser.Show()
        Me.Hide()
    End Sub

    
    Private Sub LapTrxPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LapTrxPembelianToolStripMenuItem.Click
        FromLaporanTransaksi.Show()
        Me.Hide()
    End Sub

    Private Sub TransaksiPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransaksiPembelianToolStripMenuItem.Click
        Transaksi.Show()
        Me.Hide()
    End Sub
End Class
﻿Imports System.Data.OleDb

Public Class Supplier
    'Variable
    Dim conn As OleDbConnection
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim rd As OleDbDataReader
    Dim str As String

    'Method Koneksi
    Sub Koneksi()
        ' Ganti path str sesuai dengan lokasi Connection String database.

        ' Path: Flashdisk KisahUSB
        str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 tgr\PemrogramanVB-2008\Database\db_pembelian.mdb"

        conn = New OleDbConnection(str)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub

    'Method TextMati
    Sub TextMati()
        Me.Tbkodesupplier.Enabled = False
        Me.Tbnamasupplier.Enabled = False
        Me.Tbtelepon.Enabled = False
        Me.Tbemail.Enabled = False
        Me.Tbalamat.Enabled = False
    End Sub

    'Method TextHidup
    Sub TextHidup()
        Me.Tbkodesupplier.Enabled = True
        Me.Tbnamasupplier.Enabled = True
        Me.Tbtelepon.Enabled = True
        Me.Tbemail.Enabled = True
        Me.Tbalamat.Enabled = True
    End Sub

    'Method Kosong
    Sub Kosong()
        Tbkodesupplier.Clear()
        Tbnamasupplier.Clear()
        Tbtelepon.Clear()
        Tbemail.Clear()
        Tbalamat.Focus()

    End Sub


    Private Sub Supplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilGrid()
        Call Kosong()
        Call TextMati()
        'DataBarang.ReadOnly = True   
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnUpdate.Enabled = False
        Me.btnBatal.Enabled = True
        Me.btnHapus.Enabled = True
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If Tbkodesupplier.Text = "" Or Tbnamasupplier.Text = "" Or Tbtelepon.Text = "" Or Tbemail.Text = "" Or Tbalamat.Text = "" Then
            MsgBox("Data belum lengkap, pastikan semua form terisi")
            Exit Sub
        Else
            Call Koneksi()
            Dim simpan As String = "insert into tb_supplier (kd_supplier, nm_supplier, telepon, email, alamat)" & "values ('" & Tbkodesupplier.Text & "','" & Tbnamasupplier.Text & "','" & Tbtelepon.Text & "','" & Tbemail.Text & "','" & Tbalamat.Text & "')"
            cmd = New OleDbCommand(simpan, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data berhasil di input", MsgBoxStyle.Information, "Information")
            Me.OleDbConnection1.Close()
            Call TampilGrid()
            DataSupplier.Refresh()
            Call Koneksi()
            Call Kosong()
            Call TextMati()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnEdit.Enabled = False
            Me.btnUpdate.Enabled = False
            Me.btnBatal.Enabled = False
            Me.btnHapus.Enabled = False
            Me.btnKeluar.Enabled = True
        End If
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Call TextHidup()
        Me.Tbkodesupplier.Enabled = False
        Me.btnTambah.Enabled = False
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnUpdate.Enabled = True
        Me.btnBatal.Enabled = True
        Me.btnHapus.Enabled = True
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Call TextMati()
        Call Kosong()
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnEdit.Enabled = False
        Me.btnUpdate.Enabled = False
        Me.btnBatal.Enabled = False
        Me.btnHapus.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Dim sql As String
        If MsgBox("Do you want save again ?", MsgBoxStyle.YesNo, "Message") = vbYes Then
            sql = "UPDATE tb_supplier SET nm_supplier = '" & Tbnamasupplier.Text & "', telepon = '" & Tbtelepon.Text & "', email = '" & Tbemail.Text & "', alamat = '" & Tbalamat.Text & "' where kd_supplier='" & Tbkodesupplier.Text & "'"
            cmd = New OleDbCommand(sql, conn)
            cmd.ExecuteNonQuery()
            DataSupplier.Refresh()
            Me.OleDbConnection1.Close()
            Call TextMati()
            Call Kosong()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnEdit.Enabled = False
            Me.btnUpdate.Enabled = False
            Me.btnBatal.Enabled = False
            Me.btnHapus.Enabled = False
            Me.btnKeluar.Enabled = True
            DataSupplier.Refresh()
            Call TampilGrid()
        End If
    End Sub
    'Menampilkan GridView
    Sub TampilGrid()
        da = New OleDbDataAdapter("SELECT * FROM tb_supplier", conn)
        ds = New DataSet
        da.Fill(ds, "tb_supplier")
        DataSupplier.DataSource = ds.Tables("tb_supplier")
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call Kosong()
        Call TextHidup()
        Me.btnTambah.Enabled = False
        Me.btnSimpan.Enabled = True
        Me.btnEdit.Enabled = False
        Me.btnUpdate.Enabled = False
        Me.btnBatal.Enabled = True
        Me.btnHapus.Enabled = True
        Me.btnKeluar.Enabled = True
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        If Tbkodesupplier.Text = "" Then
            MsgBox("Kode belum diisi")
            Tbkodesupplier.Focus()
            Exit Sub
        Else
            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Dim hapus As String = "Delete * from tb_supplier where kd_supplier='" & Tbkodesupplier.Text & "'"
                cmd = New OleDbCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                Call TampilGrid()
                Call Kosong()
                Me.btnTambah.Enabled = True
                Me.btnSimpan.Enabled = False
                Me.btnEdit.Enabled = False
                Me.btnUpdate.Enabled = False
                Me.btnBatal.Enabled = False
                Me.btnHapus.Enabled = False
                Me.btnKeluar.Enabled = True
            Else
                Call TextMati()
            End If
        End If
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        MenuUtama.Show()
        Me.Hide()
    End Sub

    Private Sub Tbkodesupplier_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Tbkodesupplier.KeyPress
        Tbkodesupplier.MaxLength = 5
        If e.KeyChar = Chr(13) Then Tbnamasupplier.Focus()
    End Sub

    Private Sub Tbkodesupplier_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Tbkodesupplier.LostFocus
        str = "SELECT * FROM tb_supplier Where kd_supplier = '" & Tbkodesupplier.Text & "'"
        cmd = New OleDbCommand(str, conn)
        rd = cmd.ExecuteReader
        Try
            While rd.Read
                Tbnamasupplier.Text = rd.GetString(1)
                Tbtelepon.Text = rd.GetString(2)
                Tbemail.Text = rd.GetValue(3)
                Tbalamat.Text = rd.GetValue(4)
                TextMati()
                Me.btnTambah.Enabled = False
                Me.btnSimpan.Enabled = False
                Me.btnEdit.Enabled = True
                Me.btnUpdate.Enabled = False
                Me.btnBatal.Enabled = False
                Me.btnHapus.Enabled = False
                Me.btnKeluar.Enabled = True
            End While
        Finally
            rd.Close()
        End Try
    End Sub


    Private Sub Tbnamasupplier_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Tbnamasupplier.KeyPress
        Tbnamasupplier.MaxLength = 25
        If e.KeyChar = Chr(13) Then Tbtelepon.Focus()
    End Sub

   

    Private Sub Tbtelepon_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Tbtelepon.KeyPress
        Tbtelepon.MaxLength = 10
        If e.KeyChar = Chr(13) Then Tbemail.Focus()
    End Sub


    Private Sub Tbemail_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Tbemail.KeyPress
        If e.KeyChar = Chr(13) Then Tbalamat.Focus()
    End Sub

   

    Private Sub Tbalamat_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Tbalamat.KeyPress
        If e.KeyChar = Chr(13) Then btnSimpan.Focus()
    End Sub

    Private Sub Tbemail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tbemail.TextChanged

    End Sub
End Class
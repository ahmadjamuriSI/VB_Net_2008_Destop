﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FromLaporanTransaksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CrystalReportViewer1Transaksi = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.Label1 = New System.Windows.Forms.Label
        Me.tbCariKodeTransaksi = New System.Windows.Forms.TextBox
        Me.btnTampilkan = New System.Windows.Forms.Button
        Me.btnTutup = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'CrystalReportViewer1Transaksi
        '
        Me.CrystalReportViewer1Transaksi.ActiveViewIndex = 0
        Me.CrystalReportViewer1Transaksi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CrystalReportViewer1Transaksi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CrystalReportViewer1Transaksi.Location = New System.Drawing.Point(0, 0)
        Me.CrystalReportViewer1Transaksi.Name = "CrystalReportViewer1Transaksi"
        Me.CrystalReportViewer1Transaksi.ReportSource = "C:\KULIAH PEMROGRAMAN BV.S4 tgr\PemrogramanVB-2008\PemrogramanVB-2008\LaporanTran" & _
            "saksi.rpt"
        Me.CrystalReportViewer1Transaksi.Size = New System.Drawing.Size(729, 482)
        Me.CrystalReportViewer1Transaksi.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(240, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(169, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Cari Kode Transaksi"
        '
        'tbCariKodeTransaksi
        '
        Me.tbCariKodeTransaksi.Location = New System.Drawing.Point(428, 32)
        Me.tbCariKodeTransaksi.Name = "tbCariKodeTransaksi"
        Me.tbCariKodeTransaksi.Size = New System.Drawing.Size(71, 20)
        Me.tbCariKodeTransaksi.TabIndex = 4
        '
        'btnTampilkan
        '
        Me.btnTampilkan.BackColor = System.Drawing.Color.LimeGreen
        Me.btnTampilkan.Location = New System.Drawing.Point(505, 32)
        Me.btnTampilkan.Name = "btnTampilkan"
        Me.btnTampilkan.Size = New System.Drawing.Size(75, 23)
        Me.btnTampilkan.TabIndex = 5
        Me.btnTampilkan.Text = "Tampilkan"
        Me.btnTampilkan.UseVisualStyleBackColor = False
        '
        'btnTutup
        '
        Me.btnTutup.BackColor = System.Drawing.Color.Red
        Me.btnTutup.Location = New System.Drawing.Point(595, 32)
        Me.btnTutup.Name = "btnTutup"
        Me.btnTutup.Size = New System.Drawing.Size(75, 23)
        Me.btnTutup.TabIndex = 6
        Me.btnTutup.Text = "Tutup"
        Me.btnTutup.UseVisualStyleBackColor = False
        '
        'FromLaporanTransaksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 482)
        Me.Controls.Add(Me.btnTutup)
        Me.Controls.Add(Me.btnTampilkan)
        Me.Controls.Add(Me.tbCariKodeTransaksi)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CrystalReportViewer1Transaksi)
        Me.Name = "FromLaporanTransaksi"
        Me.Text = "FromLaporanTransaksi"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CrystalReportViewer1Transaksi As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbCariKodeTransaksi As System.Windows.Forms.TextBox
    Friend WithEvents btnTampilkan As System.Windows.Forms.Button
    Friend WithEvents btnTutup As System.Windows.Forms.Button
End Class

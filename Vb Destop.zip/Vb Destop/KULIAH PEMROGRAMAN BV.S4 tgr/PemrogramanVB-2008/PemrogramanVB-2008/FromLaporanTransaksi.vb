﻿Public Class FromLaporanTransaksi

    Private Sub btnTampilkan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTampilkan.Click
        CrystalReportViewer1Transaksi.SelectionFormula = "{tbtrx.kdtrx}='" & tbCariKodeTransaksi.Text & "'"

        CrystalReportViewer1Transaksi.SelectionFormula = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 tgr\PemrogramanVB-2008\Database\db_pembelian.mdb")

        CrystalReportViewer1Transaksi.Refresh()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class
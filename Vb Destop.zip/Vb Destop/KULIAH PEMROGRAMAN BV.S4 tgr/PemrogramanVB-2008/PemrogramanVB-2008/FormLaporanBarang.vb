﻿Public Class FormLaporanBarang
    ' [BUTTON]: Digunakan untuk mengubah tampilan report.
    Private Sub btnTampilkan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTampilkan.Click
        CrystalReportViewer1.SelectionFormula = "{tb_barang.kdbarang}='" & tbCariKodeBarang.Text & "'"
        CrystalReportViewer1.ReportSource = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 tgr\PemrogramanVB-2008\Database\db_pembelian.mdb"

    End Sub

    ' [BUTTON]: Digunakan untuk menutup form.
    Private Sub btnTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTutup.Click
        MenuUtama.Show()
        Me.Hide()
    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub

    Private Sub tbCariKodeBarang_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCariKodeBarang.TextChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class
﻿Public Class FromLaporanSupplier


    Private Sub btnTampilkan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTampilkan.Click
        CrystalReportViewer2.SelectionFormula = "{tb_supplier.kd_suplier}='" & tbCariKodeSupplier.Text & "'"

        CrystalReportViewer2.SelectionFormula = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 tgr\PemrogramanVB-2008\Database\db_pembelian.mdb")

        CrystalReportViewer2.Refresh()
    End Sub

    Private Sub btnTutup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTutup.Click
        MenuUtama.Show()
        Me.Hide()
    End Sub
End Class
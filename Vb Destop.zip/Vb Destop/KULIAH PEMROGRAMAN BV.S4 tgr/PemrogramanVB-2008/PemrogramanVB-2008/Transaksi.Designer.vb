﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Transaksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Tbtanggal = New System.Windows.Forms.TextBox
        Me.TbkodeTrans = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.BtnCariKdsupplier = New System.Windows.Forms.Button
        Me.Tbemail = New System.Windows.Forms.TextBox
        Me.Tbtelepon = New System.Windows.Forms.TextBox
        Me.Tbalamat = New System.Windows.Forms.TextBox
        Me.Tbnmsupp = New System.Windows.Forms.TextBox
        Me.Tbkodesupp = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Tbnamabarang = New System.Windows.Forms.TextBox
        Me.Tbkodebarang = New System.Windows.Forms.TextBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.BtnCariKdbarang = New System.Windows.Forms.Button
        Me.Tbjumlah = New System.Windows.Forms.TextBox
        Me.Tbsatuan = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.btnSimpan = New System.Windows.Forms.Button
        Me.btnKeluar = New System.Windows.Forms.Button
        Me.btnHapus = New System.Windows.Forms.Button
        Me.btnTambah = New System.Windows.Forms.Button
        Me.btnBatal = New System.Windows.Forms.Button
        Me.btnCetak = New System.Windows.Forms.Button
        Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection
        Me.OleDbCommand1 = New System.Data.OleDb.OleDbCommand
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(178, 99)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(203, 24)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Transaksi pembelian"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(129, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(325, 20)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Jl.Raya Serang KM.10 Bitung-Tangrang"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(186, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 25)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "PT.SISFO 4A PAGI"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Tbtanggal)
        Me.GroupBox1.Controls.Add(Me.TbkodeTrans)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Location = New System.Drawing.Point(37, 176)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(517, 63)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tangga Transaksi"
        '
        'Tbtanggal
        '
        Me.Tbtanggal.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbtanggal.Location = New System.Drawing.Point(417, 31)
        Me.Tbtanggal.Name = "Tbtanggal"
        Me.Tbtanggal.Size = New System.Drawing.Size(100, 20)
        Me.Tbtanggal.TabIndex = 54
        '
        'TbkodeTrans
        '
        Me.TbkodeTrans.Location = New System.Drawing.Point(123, 31)
        Me.TbkodeTrans.Name = "TbkodeTrans"
        Me.TbkodeTrans.Size = New System.Drawing.Size(100, 20)
        Me.TbkodeTrans.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(364, 34)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Tanggal"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 31)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Kode Transaksi"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.BtnCariKdsupplier)
        Me.GroupBox2.Controls.Add(Me.Tbemail)
        Me.GroupBox2.Controls.Add(Me.Tbtelepon)
        Me.GroupBox2.Controls.Add(Me.Tbalamat)
        Me.GroupBox2.Controls.Add(Me.Tbnmsupp)
        Me.GroupBox2.Controls.Add(Me.Tbkodesupp)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(37, 260)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(517, 133)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Tangga Supplier"
        '
        'BtnCariKdsupplier
        '
        Me.BtnCariKdsupplier.Location = New System.Drawing.Point(240, 25)
        Me.BtnCariKdsupplier.Name = "BtnCariKdsupplier"
        Me.BtnCariKdsupplier.Size = New System.Drawing.Size(44, 23)
        Me.BtnCariKdsupplier.TabIndex = 53
        Me.BtnCariKdsupplier.Text = "Cari"
        Me.BtnCariKdsupplier.UseVisualStyleBackColor = True
        '
        'Tbemail
        '
        Me.Tbemail.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbemail.Location = New System.Drawing.Point(394, 60)
        Me.Tbemail.Name = "Tbemail"
        Me.Tbemail.Size = New System.Drawing.Size(100, 20)
        Me.Tbemail.TabIndex = 15
        '
        'Tbtelepon
        '
        Me.Tbtelepon.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbtelepon.Location = New System.Drawing.Point(394, 28)
        Me.Tbtelepon.Name = "Tbtelepon"
        Me.Tbtelepon.Size = New System.Drawing.Size(100, 20)
        Me.Tbtelepon.TabIndex = 14
        '
        'Tbalamat
        '
        Me.Tbalamat.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbalamat.Location = New System.Drawing.Point(123, 90)
        Me.Tbalamat.Name = "Tbalamat"
        Me.Tbalamat.Size = New System.Drawing.Size(371, 20)
        Me.Tbalamat.TabIndex = 13
        '
        'Tbnmsupp
        '
        Me.Tbnmsupp.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbnmsupp.Location = New System.Drawing.Point(123, 60)
        Me.Tbnmsupp.Name = "Tbnmsupp"
        Me.Tbnmsupp.Size = New System.Drawing.Size(150, 20)
        Me.Tbnmsupp.TabIndex = 12
        '
        'Tbkodesupp
        '
        Me.Tbkodesupp.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbkodesupp.Location = New System.Drawing.Point(123, 25)
        Me.Tbkodesupp.Name = "Tbkodesupp"
        Me.Tbkodesupp.Size = New System.Drawing.Size(111, 20)
        Me.Tbkodesupp.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(335, 63)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(37, 13)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Email"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(335, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 13)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Telepon"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(6, 93)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 13)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Alamat"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 63)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Nama Supplier"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(363, 31)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 13)
        Me.Label6.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 31)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Kode Supplier"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Tbnamabarang)
        Me.GroupBox3.Controls.Add(Me.Tbkodebarang)
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.TextBox7)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Location = New System.Drawing.Point(37, 399)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(517, 69)
        Me.GroupBox3.TabIndex = 9
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Tangga Transaksi"
        '
        'Tbnamabarang
        '
        Me.Tbnamabarang.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbnamabarang.Location = New System.Drawing.Point(154, 50)
        Me.Tbnamabarang.Name = "Tbnamabarang"
        Me.Tbnamabarang.Size = New System.Drawing.Size(150, 20)
        Me.Tbnamabarang.TabIndex = 10
        '
        'Tbkodebarang
        '
        Me.Tbkodebarang.Location = New System.Drawing.Point(6, 50)
        Me.Tbkodebarang.Name = "Tbkodebarang"
        Me.Tbkodebarang.Size = New System.Drawing.Size(100, 20)
        Me.Tbkodebarang.TabIndex = 2
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.BtnCariKdbarang)
        Me.GroupBox4.Controls.Add(Me.Tbjumlah)
        Me.GroupBox4.Controls.Add(Me.Tbsatuan)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Location = New System.Drawing.Point(0, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(517, 77)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Data Barang"
        '
        'BtnCariKdbarang
        '
        Me.BtnCariKdbarang.Location = New System.Drawing.Point(107, 48)
        Me.BtnCariKdbarang.Name = "BtnCariKdbarang"
        Me.BtnCariKdbarang.Size = New System.Drawing.Size(44, 23)
        Me.BtnCariKdbarang.TabIndex = 54
        Me.BtnCariKdbarang.Text = "Cari"
        Me.BtnCariKdbarang.UseVisualStyleBackColor = True
        '
        'Tbjumlah
        '
        Me.Tbjumlah.Location = New System.Drawing.Point(405, 47)
        Me.Tbjumlah.Name = "Tbjumlah"
        Me.Tbjumlah.Size = New System.Drawing.Size(100, 20)
        Me.Tbjumlah.TabIndex = 11
        '
        'Tbsatuan
        '
        Me.Tbsatuan.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Tbsatuan.Location = New System.Drawing.Point(310, 47)
        Me.Tbsatuan.Name = "Tbsatuan"
        Me.Tbsatuan.Size = New System.Drawing.Size(89, 20)
        Me.Tbsatuan.TabIndex = 11
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(423, 28)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(46, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Jumlah"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(181, 28)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(83, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Nama Barang"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(335, 28)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(47, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Satuan"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(6, 31)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(80, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Kode Barang"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(1, 43)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(364, 34)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Tanggal"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(6, 31)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Kode Barang"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.LimeGreen
        Me.GroupBox5.Controls.Add(Me.btnSimpan)
        Me.GroupBox5.Controls.Add(Me.btnKeluar)
        Me.GroupBox5.Controls.Add(Me.btnHapus)
        Me.GroupBox5.Controls.Add(Me.btnTambah)
        Me.GroupBox5.Controls.Add(Me.btnBatal)
        Me.GroupBox5.Controls.Add(Me.btnCetak)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 485)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(588, 76)
        Me.GroupBox5.TabIndex = 52
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "GroupBox5"
        '
        'btnSimpan
        '
        Me.btnSimpan.BackColor = System.Drawing.Color.Red
        Me.btnSimpan.Location = New System.Drawing.Point(89, 19)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(75, 39)
        Me.btnSimpan.TabIndex = 45
        Me.btnSimpan.Text = "Simpan"
        Me.btnSimpan.UseVisualStyleBackColor = False
        '
        'btnKeluar
        '
        Me.btnKeluar.BackColor = System.Drawing.Color.Red
        Me.btnKeluar.Location = New System.Drawing.Point(365, 19)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(77, 39)
        Me.btnKeluar.TabIndex = 50
        Me.btnKeluar.Text = "Tutup"
        Me.btnKeluar.UseVisualStyleBackColor = False
        '
        'btnHapus
        '
        Me.btnHapus.BackColor = System.Drawing.Color.Red
        Me.btnHapus.Location = New System.Drawing.Point(265, 19)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(75, 39)
        Me.btnHapus.TabIndex = 49
        Me.btnHapus.Text = "Hapus"
        Me.btnHapus.UseVisualStyleBackColor = False
        '
        'btnTambah
        '
        Me.btnTambah.BackColor = System.Drawing.Color.Red
        Me.btnTambah.Location = New System.Drawing.Point(8, 19)
        Me.btnTambah.Name = "btnTambah"
        Me.btnTambah.Size = New System.Drawing.Size(75, 39)
        Me.btnTambah.TabIndex = 44
        Me.btnTambah.Text = "Tambah"
        Me.btnTambah.UseVisualStyleBackColor = False
        '
        'btnBatal
        '
        Me.btnBatal.BackColor = System.Drawing.Color.MediumBlue
        Me.btnBatal.Location = New System.Drawing.Point(184, 19)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(75, 39)
        Me.btnBatal.TabIndex = 48
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.UseVisualStyleBackColor = False
        '
        'btnCetak
        '
        Me.btnCetak.BackColor = System.Drawing.Color.Red
        Me.btnCetak.Location = New System.Drawing.Point(482, 19)
        Me.btnCetak.Name = "btnCetak"
        Me.btnCetak.Size = New System.Drawing.Size(75, 39)
        Me.btnCetak.TabIndex = 47
        Me.btnCetak.Text = "Cetak"
        Me.btnCetak.UseVisualStyleBackColor = False
        '
        'OleDbConnection1
        '
        Me.OleDbConnection1.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=""C:\KULIAH PEMROGRAMAN BV.S4 tgr\Pem" & _
            "rogramanVB-2008\Database\db_pembelian.mdb"""
        '
        'Transaksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(595, 546)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Transaksi"
        Me.Text = "Transaksi"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TbkodeTrans As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Tbkodebarang As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Tbemail As System.Windows.Forms.TextBox
    Friend WithEvents Tbtelepon As System.Windows.Forms.TextBox
    Friend WithEvents Tbalamat As System.Windows.Forms.TextBox
    Friend WithEvents Tbnmsupp As System.Windows.Forms.TextBox
    Friend WithEvents Tbkodesupp As System.Windows.Forms.TextBox
    Friend WithEvents Tbnamabarang As System.Windows.Forms.TextBox
    Friend WithEvents Tbjumlah As System.Windows.Forms.TextBox
    Friend WithEvents Tbsatuan As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSimpan As System.Windows.Forms.Button
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents btnHapus As System.Windows.Forms.Button
    Friend WithEvents btnTambah As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnCetak As System.Windows.Forms.Button
    Friend WithEvents Tbtanggal As System.Windows.Forms.TextBox
    Friend WithEvents BtnCariKdsupplier As System.Windows.Forms.Button
    Friend WithEvents BtnCariKdbarang As System.Windows.Forms.Button
    Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
    Friend WithEvents OleDbCommand1 As System.Data.OleDb.OleDbCommand
End Class

﻿Imports System.Data.OleDb
Public Class Transaksi
    'Variable
    Dim conn As OleDbConnection
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim rd As OleDbDataReader
    Dim str As String

    'Method Koneksi
    Sub Koneksi()
        ' Ganti path str sesuai dengan lokasi Connection String database.

        ' Path: Flashdisk KisahUSB
        str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 tgr\PemrogramanVB-2008\Database\db_pembelian.mdb"

        conn = New OleDbConnection(str)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub

    'Method TextMati
    Sub TextMati()
        Me.TbkodeTrans.Enabled = False
        Me.Tbtanggal.Enabled = False
        Me.Tbkodesupp.Enabled = False
        Me.Tbnmsupp.Enabled = False
        Me.Tbalamat.Enabled = False
        Me.Tbtelepon.Enabled = False
        Me.Tbemail.Enabled = False
        Me.Tbkodebarang.Enabled = False
        Me.Tbnamabarang.Enabled = False
        Me.Tbsatuan.Enabled = False
        Me.Tbjumlah.Enabled = False
        Me.BtnCariKdsupplier.Enabled = False
        Me.BtnCariKdbarang.Enabled = False
    End Sub
    'Method TextHidup
    Sub TextHidup()
        Me.TbkodeTrans.Enabled = True
        Me.Tbtanggal.Enabled = True
        Me.Tbkodesupp.Enabled = True
        Me.Tbnmsupp.Enabled = True
        Me.Tbalamat.Enabled = True
        Me.Tbtelepon.Enabled = True
        Me.Tbemail.Enabled = True
        Me.Tbkodebarang.Enabled = True
        Me.Tbnamabarang.Enabled = True
        Me.Tbsatuan.Enabled = True
        Me.Tbjumlah.Enabled = True
        Me.BtnCariKdsupplier.Enabled = True
        Me.BtnCariKdbarang.Enabled = True
    End Sub
   

    Private Sub Transaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Tbtanggal.Text = Now.Date
        Call TextMati()  
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnKeluar.Enabled = True
        Me.btnBatal.Enabled = True
        Me.btnCetak.Enabled = False
        Me.btnHapus.Enabled = True
    End Sub
    'Method Kosong
    Sub Kosong()
        TbkodeTrans.Clear()
        Tbtanggal.Clear()
        Tbkodesupp.Clear()
        Tbnmsupp.Clear()
        Tbalamat.Clear()
        Tbtelepon.Clear()
        Tbemail.Clear()
        Tbkodebarang.Clear()
        Tbnamabarang.Clear()
        Tbsatuan.Clear()
        Tbjumlah.Clear()
        TbkodeTrans.Focus()
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call TextHidup()
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = True
        Me.btnCetak.Enabled = False
        Me.btnBatal.Enabled = True
        Me.btnHapus.Enabled = True
        Me.btnKeluar.Enabled = True
    End Sub
    Sub Tampilsupplier(ByVal kode As String)
        da = New OleDbDataAdapter("select * from tb_supplier where kd_supplier='" & kode & "'", conn)
        ds = New DataSet
        da.Fill(ds, "tb_supplier")
        If ds.Tables(0).Rows.Count > 0 Then
            For Each dsData As DataRow In ds.Tables(0).Rows
                Tbnmsupp.Text = dsData("nm_supplier")
                Tbalamat.Text = dsData("alamat")
                Tbtelepon.Text = dsData("telepon")
                Tbemail.Text = dsData("email")
            Next
        End If
    End Sub
    Sub Tampilbarang(ByVal kode As String)
        da = New OleDbDataAdapter("select * from tb_barang where kdbarang='" & kode & "'", conn)
        ds = New DataSet
        da.Fill(ds, "tb_barang")
        If ds.Tables(0).Rows.Count > 0 Then
            For Each dsData As DataRow In ds.Tables(0).Rows
                Tbnamabarang.Text = dsData("nmbarang")
                Tbsatuan.Text = dsData("satuan")
                Tbjumlah.Text = dsData("jumlah")
            Next
        End If
    End Sub
    'cari1
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariKdsupplier.Click
        Call Tampilsupplier(Tbkodesupp.Text)
    End Sub
    'cari2
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariKdbarang.Click
        Call Tampilbarang(Tbkodebarang.Text)
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If TbkodeTrans.Text = "" Then
            MsgBox("Data belum lengkap, pastikan semua form terisi")
            Exit Sub
        Else
            Call Koneksi()
            Dim simpan As String = "insert into tbtrx (kdtrx,kd_supplier,kdbarang,jmlbeli,tgl)" & _
            "Values ('" & TbkodeTrans.Text & "','" & Tbkodesupp.Text & "','" & Tbkodebarang.Text & "','" & Tbjumlah.Text & "','" & Tbtanggal.Text & "')"
            cmd = New OleDbCommand(simpan, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data berhasil di input", MsgBoxStyle.Information, "Information")
            Me.OleDbConnection1.Close()
            Call Koneksi()
            Call Kosong()
            Call TextMati()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnCetak.Enabled = False
            Me.btnBatal.Enabled = False
            Me.btnHapus.Enabled = False
            Me.btnKeluar.Enabled = True
        End If
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Call Koneksi()
        Call TextMati()
        Call Kosong()
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnCetak.Enabled = False
        Me.btnBatal.Enabled = False
        Me.btnHapus.Enabled = True
        Me.btnKeluar.Enabled = False
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        If TbkodeTrans.Text = "" Then
            MsgBox("Kode belum diisi")
            TbkodeTrans.Focus()
            Exit Sub
        Else
            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Dim hapus As String = "Delete * from tbtrx where kdtrx='" & TbkodeTrans.Text & "'"
                cmd = New OleDbCommand(hapus, conn)
                cmd.ExecuteNonQuery()
                'Call TampilGrid()
                Call Kosong()
                Me.btnTambah.Enabled = True
                Me.btnSimpan.Enabled = False
                Me.btnCetak.Enabled = False
                Me.btnBatal.Enabled = False
                Me.btnHapus.Enabled = False
                Me.btnKeluar.Enabled = True
            Else
                Call TextMati()
            End If
        End If
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        MenuUtama.Show()
        Me.Hide()
    End Sub


End Class
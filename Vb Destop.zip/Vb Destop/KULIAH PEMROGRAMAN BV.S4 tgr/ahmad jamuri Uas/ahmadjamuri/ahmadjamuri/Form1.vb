﻿Imports System.Data.OleDb
Public Class Form1

    'Variable
    Dim conn As OleDbConnection
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim rd As OleDbDataReader
    Dim str As String

    'Method Koneksi
    Sub Koneksi()
        ' Ganti path str sesuai dengan lokasi Connection String database.

        ' Path: Komputer LAB
        'str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\kisahtegar\2008\PemrogramanVB-2008\Database\db_pembelian.mdb"

        ' Path: Flashdisk KisahUSB
        str = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\KULIAH PEMROGRAMAN BV.S4 tgr\ahmad jamuri Uas\Dtahmad.mdb"
        conn = New OleDbConnection(str)
        If conn.State = ConnectionState.Closed Then conn.Open()
    End Sub

    'Method TextMati
    Sub TextMati()
        Me.ComboBox1.Enabled = False
        Me.ComboBox2.Enabled = False
        Me.tbHarga.Enabled = False
    End Sub

    'Method TextHidup
    Sub TextHidup()
        Me.ComboBox1.Enabled = True
        Me.ComboBox2.Enabled = True
        Me.tbHarga.Enabled = True
    End Sub

    'Method Kosong
    Sub Kosong()
        tbHarga.Focus()
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If ComboBox1.Text = "" Or ComboBox2.Text = "" Or tbHarga.Text = "" Then
            MsgBox("Data belum lengkap, pastikan semua form terisi")
            Exit Sub
        Else
            Call Koneksi()
            Dim simpan As String = "insert into tbahmad (kdfls,nmfls,harga)" & "values ('" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & tbHarga.Text & "')"
            cmd = New OleDbCommand(simpan, conn)
            'cmd.ExecuteNonQuery()
            MsgBox("Data berhasil di input", MsgBoxStyle.Information, "Information")
            Me.OleDbConnection1.Close()
            Call TampilGrid()
            DataGridView1.Refresh()
            Call Koneksi()
            Call Kosong()
            Call TextMati()
            Me.btnTambah.Enabled = True
            Me.btnSimpan.Enabled = False
            Me.btnpreview.Enabled = False
            Me.btnKeluar.Enabled = True
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilGrid()
        Call Kosong()
        Call TextMati()
        DataGridView1.ReadOnly = True
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = False
        Me.btnpreview.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub
    Sub TampilGrid()
        da = New OleDbDataAdapter("SELECT * FROM tbahmad", conn)
        ds = New DataSet
        da.Fill(ds, "tbahmad")
        DataGridView1.DataSource = ds.Tables("tbahmad")
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call Kosong()
        Call TextHidup()
        Me.btnTambah.Enabled = True
        Me.btnSimpan.Enabled = True
        Me.btnpreview.Enabled = False
        Me.btnKeluar.Enabled = True
    End Sub
End Class
